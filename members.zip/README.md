## 🏆 Pokétwo Autocatcher 🏆
A second generation **free** and open-source Pokétwo autocatcher, created with the goal of preventing people from wasting their money.

---

### Features
The bot has the following features:
- ⚙️ Easy Setup (simply run a script and enter the correct information, no 'coding' needed)
- ⬆️ Auto-levelling (Level up all your duel Pokémon to level 100 **overnight**!)
- ✨ Get notified when and if you've caught a Pokémon, and also if another event occurs
    - See when a Shiny/Legendary/Ultra Beast/Mythical Pokémon is caught, and which one it is!
- 💲 **Completely free** and open-source (you can see the code as it is currently)
- 💕 **Trustworthy**; this autocatcher is **completely** open-source (meaning you can see the latest code)
- 📜 Support for all Pokémon from generation I to generation VIII, including all Alolan and Galarian Pokémon
- 🏎️ Super fast; the autocatcher can even handle Incense!
- 🔍 Pokétwo-Resistant - the autocatcher sends a random series of numbers to enhance undetectability

### Getting Started:
To start up the bot on replit, go to the 'Secrets' tab on replit (the lock icon) and in the 'key' area, write `user_token`, and then type in your discord account token in the 'value' section. <br>

Then, create another secret with `spam_id` in the 'key' section, and type in the channel id you want the bot to spam in into the 'value' section. <br>

Then, create another secret with `catch_id` in the 'key' section, and type in the channel id you want the bot to catch in into the 'value' section. <br>

After you've done that, please see the below section.

#### <b>Running</b>
Once you have installed the correct dependencies, click the green 'Run' icon at the top of your webpage. If a new window opens up with 'Bot logged on' written inside, and `Logged into account: <account name>` has appeared into your console, then the bot has successfully started.

> Remember to cd into your autocatcher folder as well. If you need any help with something, feel free to open a Github Issue.

### Auto-levelling
To enable auto-levelling, just put in the ID's of the Pokémon you want to be levelled up into the `level` file (inside the `data` folder).

---

## **DISCLAIMER**

Please note that self botting is against Discord's Terms of Service and being discovered using a self bot may result in your account being banned. To avoid this, keep knowledge of your self bot to a minimum and use a throwaway account. I am not responsible for any accounts lost due to the self bot. I also recommend checking the self bot channel's messages occasionally to see if Pokétwo has sent a captcha. **If it has, it would be a good idea to solve it.**

---